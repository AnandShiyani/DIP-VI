import cv2
import numpy as np
img = cv2. imread ('Sea.jpg', 1)
kernel = np.ones((3, 3), np.uint8)
img_erosion = cv2.erode(img, kernel, iterations=1)
subt=cv2. subtract (img,img_erosion)
img_dilation = cv2.dilate(img, kernel, iterations=1)
cv2.imshow('Input', img)
cv2.imshow ('Erosion', img_erosion)
cv2.imshow('Subtracted image',subt)
cv2.imshow('Dilation', img_dilation)
cv2.waitKey (0)
