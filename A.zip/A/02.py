import numpy as np
import cv2
image = cv2.imread('Labro.jpg')
height, width = image.shape[: 2]
center = (width/2, height/2)
rotate_matrix = cv2.getRotationMatrix2D(center=center, angle=45, scale=1)
rotated_image = cv2.warpAffine(src=image, M=rotate _matrix, dsize=(width, height))
cv2.imshow('Original image', image)
cv2.imshow('Rotated image', rotated image)
cv2.imwrite('rotated image.jpg', rotated image)
tx, ty = width / 4, height / 4
translation_matrix =np.array([[1, 0, tx], [0, 1, ty]],dtype=np.float32)
translated_image =cv2.warpAffine (src=image, M=translation_matrix,dsize=(width, height))
cv2. imshow('Translated image', translated image
cv2.imwrite('translated image.jpg', translated image)
