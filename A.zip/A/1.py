import cv2
import numpy as np

def split_image_into_quadrants(img):
 
  height = img.shape[0]
  width = img.shape[1]
  # Cut the image in half horizontally and vertically.
  l1 = img[:, :width // 2]
  r1 = img[:, width // 2:]
  t1 = img[:height // 2, :]
  b1 = img[height // 2:, :]
  # Rotate each quadrant 90 degrees counter-clockwise.
  l1 = cv2.rotate(l1, cv2.ROTATE_90_COUNTERCLOCKWISE)
  r1 = cv2.rotate(r1, cv2.ROTATE_90_COUNTERCLOCKWISE)
  t1 = cv2.rotate(t1, cv2.ROTATE_90_COUNTERCLOCKWISE)
  b1 = cv2.rotate(b1, cv2.ROTATE_90_COUNTERCLOCKWISE)
  return l1, r1, t1, b1

if __name__ == "__main__":
  img = cv2.imread("Download.jpg")
  quadrants = split_image_into_quadrants(img)
  for quadrant in quadrants:
    cv2.imshow("Quadrant", quadrant)
    cv2.waitKey(0)

