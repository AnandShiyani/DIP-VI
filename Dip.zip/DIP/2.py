import cv2
import numpy as np

def rotate_image(image, angle):
  """Rotates an image by the specified angle."""
  center = (image.shape[1] // 2, image.shape[0] // 2)
  rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
  rotated_image = cv2.warpAffine(image, rotation_matrix, (image.shape[1], image.shape[0]))
  return rotated_image

def translate_image(image, tx, ty):
  """Translates an image by the specified tx and ty values."""
  translation_matrix = np.array([[1, 0, tx], [0, 1, ty]], dtype=np.float32)
  translated_image = cv2.warpAffine(image, translation_matrix, (image.shape[1], image.shape[0]))
  return translated_image

if __name__ == "__main__":
  image = cv2.imread("Labro.jpg")

  # Rotate the image by 45 degrees.
  rotated_image = rotate_image(image, 45)

  # Translate the image by 1/4 of its width and height.
  translated_image = translate_image(image, image.shape[1] // 4, image.shape[0] // 4)

  # Display the original and the rotated/translated images.
  cv2.imshow("Original image", image)
  cv2.imshow("Rotated image", rotated_image)
  cv2.imshow("Translated image", translated_image)
  cv2.waitKey(0)
