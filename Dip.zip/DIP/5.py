import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread("Low.jpg")

# Adjust the brightness and contrast
brightness = 10
contrast = 2.3
image2 = cv2.addWeighted(image, contrast, np.zeros_like(image), 0, brightness)

# Sharpen the image
kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
sharpened_image = cv2.filter2D(image, -1, kernel)

# Show the images
plt.subplot(1, 2, 1)
plt.title("Original")
plt.imshow(image)

plt.subplot(1, 2, 2)
plt.title("Brightness & contrast")
plt.imshow(image2)

plt.show()
