import imageio.v2 as imageio
import matplotlib.pyplot as plt
# Load and show image
pic = imageio.imread('Sea.jpg')
plt.imshow(pic)
plt.waitforbuttonpress()
# Getting basic properties
print('Type of the image : ',type(pic))
print('Shape of the image : {}'.format(pic.shape))
print('Image Height : {}'.format(pic.shape[0]))
print('Image Width : {}'.format(pic.shape[1]))
megapixels = (pic.shape[0]*pic.shape[1]/1000000)
print('Megapixels : {}'.format(megapixels))
print('Dimension of Image : {}'.format(pic.ndim))
print('Value of only R channel {}'.format(pic[100, 50, 0])) #Red
print('Value of only G channel {}'.format(pic[100, 50, 1])) #Green
print('Value of only B channel {}'.format(pic[100, 50, 2])) #Blue
