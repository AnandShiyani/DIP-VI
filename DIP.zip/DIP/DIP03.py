# Python program to demonstrate erosion and
# dilation of images.
import cv2
import numpy as np
img = cv2.imread('sea.jpg',cv2.IMREAD_UNCHANGED)
#cv2.imshow(img)
#cv2.waitKey(20) 
# Taking a matrix of size 5 as the kernel
skernel = np.ones((5, 5), np.double)
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
image_1 = cv2.erode(img, kernel, iterations=1)
img_erosion = cv2.erode(img,kernel,iterations=1)
subt=cv2.subtract(img,img_erosion)
img_dilation = cv2.dilate(img,kernel,iterations=1)
cv2.imshow('Input',img)
cv2.imwrite('Input.jpg',img)
cv2.waitKey(0)
cv2.imshow('Erosion',img_erosion)
cv2.imwrite('Erosion.jpg',img_erosion)
cv2.waitKey(0)
cv2.imshow('Subtracted image',subt)
cv2.imwrite('Subtracted image.jpg',subt)
cv2.waitKey(0)
cv2.imshow('Dilation',img_dilation)
cv2.imwrite('Dilation.jpg',img_dilation)
cv2.waitKey(0)
