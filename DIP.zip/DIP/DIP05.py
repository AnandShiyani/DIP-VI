#Import the necessary libraries
import cv2
import matplotlib.pyplot as plt
import numpy as np
  
# Load the image
image = cv2.imread("Low.jpg")
  
#Plot the original image
plt.subplot(1, 2, 1)
plt.title("Original")
plt.imshow(image)
plt.waitforbuttonpress()
  
# Adjust the brightness and contrast
# Adjusts the brightness by adding 10 to each pixel value
brightness = 10 
# Adjusts the contrast by scaling the pixel values by 2.3
contrast = 2.3  
image2 = cv2.addWeighted(image, contrast, np.zeros(image.shape, image.dtype), 0, brightness)
  
#Save the image
cv2.imwrite('modified_image.jpg', image2)
#Plot the contrast image
plt.subplot(1, 2, 2)
plt.title("Brightness & contrast")
plt.imshow(image2)
plt.waitforbuttonpress()
plt.show()

kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
  
# Sharpen the image
sharpened_image = cv2.filter2D(image, -1, kernel)
  
#Save the image
cv2.imwrite('sharpened_image.jpg', sharpened_image)
  
#Plot the sharpened image
plt.subplot(1, 2, 2)
plt.title("Sharpening")
plt.imshow(sharpened_image)
plt.waitforbuttonpress()
plt.show()
cv2.destroyallwindows
